data class User(val login: String, val id: Int)

fun compareUsers(): Boolean {
    val user1 = User("admin", 1)
    val user2 = User("admin", 1)
    return user1 == user2 // Тепер поверне true
}