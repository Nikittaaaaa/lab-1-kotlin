class Modifier(val id: String)
fun Box(modifier: Modifier): String = "Box with ${modifier.id}"

fun createBox(): String {
    val modifier = Modifier("ID_1")
    return Box(modifier)
}